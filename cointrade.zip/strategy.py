import pandas as pd
import numpy as np

def myStrategyRSI(coin_data):
    df = coin_data.df

    mtb = np.where(
                    ((df['trade_price']-df['MA3']) > 0) |
                    ((df['trade_price']-df['MA5']) > 0) |
                    ((df['trade_price']-df['MA10'])> 0) , True, False)

    rsiUp = np.where((df['RSI']-df['rsiMA3']) > 0, True, False)

    condBuy = mtb & rsiUp & (df['RSI']>60)


    mts = np.where(
                    ((df['trade_price']-df['MA3']) < 0) &
                    ((df['trade_price']-df['MA5']) < 0) &
                    ((df['trade_price']-df['MA10'])< 0) , True, False)

    condSell = mts | (df['RSI']<65)

    return condBuy, condSell