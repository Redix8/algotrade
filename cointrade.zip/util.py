import requests

def top30TradingValue():
    
    return